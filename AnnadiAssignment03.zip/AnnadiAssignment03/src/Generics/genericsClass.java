package Generics;

public class genericsClass<T> {
	private T detail;

	public genericsClass(T detail) {
		super();
		this.detail = detail;
	}

	public T getDetail() {
		return detail;
	}

	public void setDetail(T detail) {
		this.detail = detail;
	}
}
