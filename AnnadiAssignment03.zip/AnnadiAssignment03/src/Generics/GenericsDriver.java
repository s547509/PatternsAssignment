package Generics;

public class GenericsDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		genericsClass<String> stringClass = new genericsClass<>("Hello, Everyone!");
		String detail = stringClass.getDetail();

	}

}
