package staticAndPrivate;

public class staticAndPrivateDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal.makeSound();
		Donkey.makeSound();

	}

}
