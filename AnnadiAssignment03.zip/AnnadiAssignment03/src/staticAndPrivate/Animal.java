package staticAndPrivate;

public class Animal {
	public static void makeSound() {
		System.out.println("Animal making sound");
	}
}
