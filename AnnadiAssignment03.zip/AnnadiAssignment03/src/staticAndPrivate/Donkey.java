package staticAndPrivate;

public class Donkey extends Animal{
	
	public static void makeSound() {
		System.out.println("Donkey is shouting");
	}
}
