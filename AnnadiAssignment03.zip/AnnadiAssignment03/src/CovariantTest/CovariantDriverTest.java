package CovariantTest;

public class CovariantDriverTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Mammal().getInstance().move();

	}

}
