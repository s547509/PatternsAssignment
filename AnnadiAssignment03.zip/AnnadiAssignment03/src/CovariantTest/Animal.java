package CovariantTest;

public class Animal {
	public Animal getInstance() {
		return this;
	}
	public void move() {
		System.out.println("Animal is producing");
	}
}
