package CovariantTest;

public class Mammal extends Animal {
	public Mammal reproduce() {
		System.out.println("Mammal is reproducing");
		return new Mammal();
	}
	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("Mammal is producing");
	}
}
